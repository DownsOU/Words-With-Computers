function openTheGame() {
	
//	WshShell = new ActiveXObject("Wscript.Shell"); //Create WScript Object
     //   WshShell.run("C:\Program Files\NetBeans 8.2\bin\netbeans64.exe"); 
     //  }
	
}