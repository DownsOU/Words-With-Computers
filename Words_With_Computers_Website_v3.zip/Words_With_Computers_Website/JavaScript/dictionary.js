//This will refresh the page when the 'Reset Search' button is clicked. 
function pageRefresh() {
	location.reload();
}
//This will open the wordnik page to get the dictionary words
function searchWord() {
	 document.getElementById('sResult').style.visibility = 'visible';

    var word = document.getElementById('word');
    var definition = document.getElementById('definition');

    var wordSearch = document.getElementById('sBox').value;

    var request = new XMLHttpRequest();
    request.open('GET', 'https://api.wordnik.com/v4/word.json/' + wordSearch + '/definitions?limit=10&includeRelated=false&useCanonical=false&includeTags=false&api_key=dioklaaa0kksnep3ib1t6zw3xa8yx5c1wfw1lo711cor994kl', true);
    request.onload = function () {
        var data = JSON.parse(this.response);
        if (request.status >= 200 && request.status < 400) {
            var i = Math.ceil(Math.random() * 10);      //  get a random number from 1 to 10
            word.innerHTML = data[i].word;      //  get a random definition
            definition.innerHTML = data[i].text;
        } else {
            word.innerHTML = "Error";
            definition.innerHTML = "Error";
        }
    }
    request.send();
}
